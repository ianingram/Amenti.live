MY FIRST BOOK: ‘TREASURE ISLAND’

It was far indeed from being my first book, for I am not a novelist
alone.  But I am well aware that my paymaster, the Great Public, regards
what else I have written with indifference, if not aversion; if it call
upon me at all, it calls on me in the familiar and indelible character;
and when I am asked to talk of my first book, no question in the world
but what is meant is my first novel.

Sooner or later, somehow, anyhow, I was bound to write a novel.  It seems
vain to ask why.  Men are born with various manias: from my earliest
childhood, it was mine to make a plaything of imaginary series of events;
and as soon as I was able to write, I became a good friend to the
paper-makers.  Reams upon reams must have gone to the making of
‘Rathillet,’ ‘The Pentland Rising,’ ‘The King’s Pardon’ (otherwise
‘Park Whitehead’), ‘Edward Daven,’ ‘A Country Dance,’ and ‘A Vendetta in
the West’; and it is consolatory to remember that these reams are now all
ashes, and have been received again into the soil.  I have named but a
few of my ill-fated efforts, only such indeed as came to a fair bulk ere
they were desisted from; and even so they cover a long vista of years.
‘Rathillet’ was attempted before fifteen, ‘The Vendetta’ at twenty-nine,
and the succession of defeats lasted unbroken till I was thirty-one.  By
that time, I had written little books and little essays and short
stories; and had got patted on the back and paid for them—though not
enough to live upon.  I had quite a reputation, I was the successful man;
I passed my days in toil, the futility of which would sometimes make my
cheek to burn—that I should spend a man’s energy upon this business, and
yet could not earn a livelihood: and still there shone ahead of me an
unattained ideal: although I had attempted the thing with vigour not less
than ten or twelve times, I had not yet written a novel.  All—all my
pretty ones—had gone for a little, and then stopped inexorably like a
schoolboy’s watch.  I might be compared to a cricketer of many years’
standing who should never have made a run.  Anybody can write a short
story—a bad one, I mean—who has industry and paper and time enough; but
not every one may hope to write even a bad novel.  It is the length that
kills.

The accepted novelist may take his novel up and put it down, spend days
upon it in vain, and write not any more than he makes haste to blot.  Not
so the beginner.  Human nature has certain rights; instinct—the instinct
of self-preservation—forbids that any man (cheered and supported by the
consciousness of no previous victory) should endure the miseries of
unsuccessful literary toil beyond a period to be measured in weeks.
There must be something for hope to feed upon.  The beginner must have a
slant of wind, a lucky vein must be running, he must be in one of those
hours when the words come and the phrases balance of themselves—_even to
begin_.  And having begun, what a dread looking forward is that until the
book shall be accomplished!  For so long a time, the slant is to continue
unchanged, the vein to keep running, for so long a time you must keep at
command the same quality of style: for so long a time your puppets are to
be always vital, always consistent, always vigorous!  I remember I used
to look, in those days, upon every three-volume novel with a sort of
veneration, as a feat—not possibly of literature—but at least of physical
and moral endurance and the courage of Ajax.

In the fated year I came to live with my father and mother at Kinnaird,
above Pitlochry.  Then I walked on the red moors and by the side of the
golden burn; the rude, pure air of our mountains inspirited, if it did
not inspire us, and my wife and I projected a joint volume of logic
stories, for which she wrote ‘The Shadow on the Bed,’ and I turned out
‘Thrawn Janet,’ and a first draft of ‘The Merry Men.’  I love my native
air, but it does not love me; and the end of this delightful period was a
cold, a fly-blister, and a migration by Strathairdle and Glenshee to the
Castleton of Braemar.

There it blew a good deal and rained in a proportion; my native air was
more unkind than man’s ingratitude, and I must consent to pass a good
deal of my time between four walls in a house lugubriously known as the
Late Miss McGregor’s Cottage.  And now admire the finger of
predestination.  There was a schoolboy in the Late Miss McGregor’s
Cottage, home from the holidays, and much in want of ‘something craggy to
break his mind upon.’  He had no thought of literature; it was the art of
Raphael that received his fleeting suffrages; and with the aid of pen and
ink and a shilling box of water colours, he had soon turned one of the
rooms into a picture gallery.  My more immediate duty towards the gallery
was to be showman; but I would sometimes unbend a little, join the artist
(so to speak) at the easel, and pass the afternoon with him in a generous
emulation, making coloured drawings.  On one of these occasions, I made
the map of an island; it was elaborately and (I thought) beautifully
coloured; the shape of it took my fancy beyond expression; it contained
harbours that pleased me like sonnets; and with the unconsciousness of
the predestined, I ticketed my performance ‘Treasure Island.’  I am told
there are people who do not care for maps, and find it hard to believe.
The names, the shapes of the woodlands, the courses of the roads and
rivers, the prehistoric footsteps of man still distinctly traceable up
hill and down dale, the mills and the ruins, the ponds and the ferries,
perhaps the _Standing Stone_ or the _Druidic Circle_ on the heath; here
is an inexhaustible fund of interest for any man with eyes to see or
twopence-worth of imagination to understand with!  No child but must
remember laying his head in the grass, staring into the infinitesimal
forest and seeing it grow populous with fairy armies.

Somewhat in this way, as I paused upon my map of ‘Treasure Island,’ the
future character of the book began to appear there visibly among
imaginary woods; and their brown faces and bright weapons peeped out upon
me from unexpected quarters, as they passed to and fro, fighting and
hunting treasure, on these few square inches of a flat projection.  The
next thing I knew I had some papers before me and was writing out a list
of chapters.  How often have I done so, and the thing gone no further!
But there seemed elements of success about this enterprise.  It was to be
a story for boys; no need of psychology or fine writing; and I had a boy
at hand to be a touchstone.  Women were excluded.  I was unable to handle
a brig (which the _Hispaniola_ should have been), but I thought I could
make shift to sail her as a schooner without public shame.  And then I
had an idea for John Silver from which I promised myself funds of
entertainment; to take an admired friend of mine (whom the reader very
likely knows and admires as much as I do), to deprive him of all his
finer qualities and higher graces of temperament, to leave him with
nothing but his strength, his courage, his quickness, and his magnificent
geniality, and to try to express these in terms of the culture of a raw
tarpaulin.  Such psychical surgery is, I think, a common way of ‘making
character’; perhaps it is, indeed, the only way.  We can put in the
quaint figure that spoke a hundred words with us yesterday by the
wayside; but do we know him?  Our friend, with his infinite variety and
flexibility, we know—but can we put him in?  Upon the first, we must
engraft secondary and imaginary qualities, possibly all wrong; from the
second, knife in hand, we must cut away and deduct the needless
arborescence of his nature, but the trunk and the few branches that
remain we may at least be fairly sure of.

On a chill September morning, by the cheek of a brisk fire, and the rain
drumming on the window, I began _The Sea Cook_, for that was the original
title.  I have begun (and finished) a number of other books, but I cannot
remember to have sat down to one of them with more complacency.  It is
not to be wondered at, for stolen waters are proverbially sweet.  I am
now upon a painful chapter.  No doubt the parrot once belonged to
Robinson Crusoe.  No doubt the skeleton is conveyed from Poe.  I think
little of these, they are trifles and details; and no man can hope to
have a monopoly of skeletons or make a corner in talking birds.  The
stockade, I am told, is from _Masterman Ready_.  It may be, I care not a
jot.  These useful writers had fulfilled the poet’s saying: departing,
they had left behind them Footprints on the sands of time, Footprints
which perhaps another—and I was the other!  It is my debt to Washington
Irving that exercises my conscience, and justly so, for I believe
plagiarism was rarely carried farther.  I chanced to pick up the _Tales
of a Traveller_ some years ago with a view to an anthology of prose
narrative, and the book flew up and struck me: Billy Bones, his chest,
the company in the parlour, the whole inner spirit, and a good deal of
the material detail of my first chapters—all were there, all were the
property of Washington Irving.  But I had no guess of it then as I sat
writing by the fireside, in what seemed the spring-tides of a somewhat
pedestrian inspiration; nor yet day by day, after lunch, as I read aloud
my morning’s work to the family.  It seemed to me original as sin; it
seemed to belong to me like my right eye.  I had counted on one boy, I
found I had two in my audience.  My father caught fire at once with all
the romance and childishness of his original nature.  His own stories,
that every night of his life he put himself to sleep with, dealt
perpetually with ships, roadside inns, robbers, old sailors, and
commercial travellers before the era of steam.  He never finished one of
these romances; the lucky man did not require to!  But in _Treasure
Island_ he recognised something kindred to his own imagination; it was
_his_ kind of picturesque; and he not only heard with delight the daily
chapter, but set himself acting to collaborate.  When the time came for
Billy Bones’s chest to be ransacked, he must have passed the better part
of a day preparing, on the back of a legal envelope, an inventory of its
contents, which I exactly followed; and the name of ‘Flint’s old
ship’—the _Walrus_—was given at his particular request.  And now who
should come dropping in, _ex machinâ_, but Dr. Japp, like the disguised
prince who is to bring down the curtain upon peace and happiness in the
last act; for he carried in his pocket, not a horn or a talisman, but a
publisher—had, in fact, been charged by my old friend, Mr. Henderson, to
unearth new writers for _Young Folks_.  Even the ruthlessness of a united
family recoiled before the extreme measure of inflicting on our guest the
mutilated members of _The Sea Cook_; at the same time, we would by no
means stop our readings; and accordingly the tale was begun again at the
beginning, and solemnly re-delivered for the benefit of Dr. Japp.  From
that moment on, I have thought highly of his critical faculty; for when
he left us, he carried away the manuscript in his portmanteau.

Here, then, was everything to keep me up, sympathy, help, and now a
positive engagement.  I had chosen besides a very easy style.  Compare it
with the almost contemporary ‘Merry Men’, one reader may prefer the one
style, one the other—’tis an affair of character, perhaps of mood; but no
expert can fail to see that the one is much more difficult, and the other
much easier to maintain.  It seems as though a full-grown experienced man
of letters might engage to turn out _Treasure Island_ at so many pages a
day, and keep his pipe alight.  But alas! this was not my case.  Fifteen
days I stuck to it, and turned out fifteen chapters; and then, in the
early paragraphs of the sixteenth, ignominiously lost hold.  My mouth was
empty; there was not one word of _Treasure Island_ in my bosom; and here
were the proofs of the beginning already waiting me at the ‘Hand and
Spear’!  Then I corrected them, living for the most part alone, walking
on the heath at Weybridge in dewy autumn mornings, a good deal pleased
with what I had done, and more appalled than I can depict to you in words
at what remained for me to do.  I was thirty-one; I was the head of a
family; I had lost my health; I had never yet paid my way, never yet made
£200 a year; my father had quite recently bought back and cancelled a
book that was judged a failure: was this to be another and last fiasco?
I was indeed very close on despair; but I shut my mouth hard, and during
the journey to Davos, where I was to pass the winter, had the resolution
to think of other things and bury myself in the novels of M. de
Boisgobey.  Arrived at my destination, down I sat one morning to the
unfinished tale; and behold! it flowed from me like small talk; and in a
second tide of delighted industry, and again at a rate of a chapter a
day, I finished _Treasure Island_.  It had to be transcribed almost
exactly; my wife was ill; the schoolboy remained alone of the faithful;
and John Addington Symonds (to whom I timidly mentioned what I was
engaged on) looked on me askance.  He was at that time very eager I
should write on the characters of Theophrastus: so far out may be the
judgments of the wisest men.  But Symonds (to be sure) was scarce the
confidant to go to for sympathy on a boy’s story.  He was large-minded;
‘a full man,’ if there was one; but the very name of my enterprise would
suggest to him only capitulations of sincerity and solecisms of style.
Well! he was not far wrong.

_Treasure Island_—it was Mr. Henderson who deleted the first title, _The
Sea Cook_—appeared duly in the story paper, where it figured in the
ignoble midst, without woodcuts, and attracted not the least attention.
I did not care.  I liked the tale myself, for much the same reason as my
father liked the beginning: it was my kind of picturesque.  I was not a
little proud of John Silver, also; and to this day rather admire that
smooth and formidable adventurer.  What was infinitely more exhilarating,
I had passed a landmark; I had finished a tale, and written ‘The End’
upon my manuscript, as I had not done since ‘The Pentland Rising,’ when I
was a boy of sixteen not yet at college.  In truth it was so by a set of
lucky accidents; had not Dr. Japp come on his visit, had not the tale
flowed from me with singular case, it must have been laid aside like its
predecessors, and found a circuitous and unlamented way to the fire.
Purists may suggest it would have been better so.  I am not of that mind.
The tale seems to have given much pleasure, and it brought (or, was the
means of bringing) fire and food and wine to a deserving family in which
I took an interest.  I need scarcely say I mean my own.

But the adventures of _Treasure Island_ are not yet quite at an end.  I
had written it up to the map.  The map was the chief part of my plot.
For instance, I had called an islet ‘Skeleton Island,’ not knowing what I
meant, seeking only for the immediate picturesque, and it was to justify
this name that I broke into the gallery of Mr. Poe and stole Flint’s
pointer.  And in the same way, it was because I had made two harbours
that the _Hispaniola_ was sent on her wanderings with Israel Hands.  The
time came when it was decided to republish, and I sent in my manuscript,
and the map along with it, to Messrs. Cassell.  The proofs came, they
were corrected, but I heard nothing of the map.  I wrote and asked; was
told it had never been received, and sat aghast.  It is one thing to draw
a map at random, set a scale in one corner of it at a venture, and write
up a story to the measurements.  It is quite another to have to examine a
whole book, make an inventory of all the allusions contained in it, and
with a pair of compasses, painfully design a map to suit the data.  I did
it; and the map was drawn again in my father’s office, with
embellishments of blowing whales and sailing ships, and my father himself
brought into service a knack he had of various writing, and elaborately
_forged_ the signature of Captain Flint, and the sailing directions of
Billy Bones.  But somehow it was never _Treasure Island_ to me.

I have said the map was the most of the plot.  I might almost say it was
the whole.  A few reminiscences of Poe, Defoe, and Washington Irving, a
copy of Johnson’s _Buccaneers_, the name of the Dead Man’s Chest from
Kingsley’s _At Last_, some recollections of canoeing on the high seas,
and the map itself, with its infinite, eloquent suggestion, made up the
whole of my materials.  It is, perhaps, not often that a map figures so
largely in a tale, yet it is always important.  The author must know his
countryside, whether real or imaginary, like his hand; the distances, the
points of the compass, the place of the sun’s rising, the behaviour of
the moon, should all be beyond cavil.  And how troublesome the moon is!
I have come to grief over the moon in _Prince Otto_, and so soon as that
was pointed out to me, adopted a precaution which I recommend to other
men—I never write now without an almanack.  With an almanack, and the map
of the country, and the plan of every house, either actually plotted on
paper or already and immediately apprehended in the mind, a man may hope
to avoid some of the grossest possible blunders.  With the map before
him, he will scarce allow the sun to set in the east, as it does in _The
Antiquary_.  With the almanack at hand, he will scarce allow two
horsemen, journeying on the most urgent affair, to employ six days, from
three of the Monday morning till late in the Saturday night, upon a
journey of, say, ninety or a hundred miles, and before the week is out,
and still on the same nags, to cover fifty in one day, as may be read at
length in the inimitable novel of _Rob Roy_.  And it is certainly well,
though far from necessary, to avoid such ‘croppers.’  But it is my
contention—my superstition, if you like—that who is faithful to his map,
and consults it, and draws from it his inspiration, daily and hourly,
gains positive support, and not mere negative immunity from accident.
The tale has a root there; it grows in that soil; it has a spine of its
own behind the words.  Better if the country be real, and he has walked
every foot of it and knows every milestone.  But even with imaginary
places, he will do well in the beginning to provide a map; as he studies
it, relations will appear that he had not thought upon; he will discover
obvious, though unsuspected, short-cuts and footprints for his
messengers; and even when a map is not all the plot, as it was in
_Treasure Island_, it will be found to be a mine of suggestion.
