HENRY JEKYLL’S FULL STATEMENT OF THE CASE

I was born in the year 18— to a large fortune, endowed besides with
excellent parts, inclined by nature to industry, fond of the respect of
the wise and good among my fellowmen, and thus, as might have been
supposed, with every guarantee of an honourable and distinguished
future. And indeed the worst of my faults was a certain impatient
gaiety of disposition, such as has made the happiness of many, but such
as I found it hard to reconcile with my imperious desire to carry my
head high, and wear a more than commonly grave countenance before the
public. Hence it came about that I concealed my pleasures; and that
when I reached years of reflection, and began to look round me and take
stock of my progress and position in the world, I stood already
committed to a profound duplicity of life. Many a man would have even
blazoned such irregularities as I was guilty of; but from the high
views that I had set before me, I regarded and hid them with an almost
morbid sense of shame. It was thus rather the exacting nature of my
aspirations than any particular degradation in my faults, that made me
what I was, and, with even a deeper trench than in the majority of men,
severed in me those provinces of good and ill which divide and compound
man’s dual nature. In this case, I was driven to reflect deeply and
inveterately on that hard law of life, which lies at the root of
religion and is one of the most plentiful springs of distress. Though
so profound a double-dealer, I was in no sense a hypocrite; both sides
of me were in dead earnest; I was no more myself when I laid aside
restraint and plunged in shame, than when I laboured, in the eye of
day, at the furtherance of knowledge or the relief of sorrow and
suffering. And it chanced that the direction of my scientific studies,
which led wholly towards the mystic and the transcendental, reacted and
shed a strong light on this consciousness of the perennial war among my
members. With every day, and from both sides of my intelligence, the
moral and the intellectual, I thus drew steadily nearer to that truth,
by whose partial discovery I have been doomed to such a dreadful
shipwreck: that man is not truly one, but truly two. I say two, because
the state of my own knowledge does not pass beyond that point. Others
will follow, others will outstrip me on the same lines; and I hazard
the guess that man will be ultimately known for a mere polity of
multifarious, incongruous and independent denizens. I, for my part,
from the nature of my life, advanced infallibly in one direction and in
one direction only. It was on the moral side, and in my own person,
that I learned to recognise the thorough and primitive duality of man;
I saw that, of the two natures that contended in the field of my
consciousness, even if I could rightly be said to be either, it was
only because I was radically both; and from an early date, even before
the course of my scientific discoveries had begun to suggest the most
naked possibility of such a miracle, I had learned to dwell with
pleasure, as a beloved daydream, on the thought of the separation of
these elements. If each, I told myself, could be housed in separate
identities, life would be relieved of all that was unbearable; the
unjust might go his way, delivered from the aspirations and remorse of
his more upright twin; and the just could walk steadfastly and securely
on his upward path, doing the good things in which he found his
pleasure, and no longer exposed to disgrace and penitence by the hands
of this extraneous evil. It was the curse of mankind that these
incongruous faggots were thus bound together—that in the agonised womb
of consciousness, these polar twins should be continuously struggling.
How, then were they dissociated?

I was so far in my reflections when, as I have said, a side light began
to shine upon the subject from the laboratory table. I began to
perceive more deeply than it has ever yet been stated, the trembling
immateriality, the mistlike transience, of this seemingly so solid body
in which we walk attired. Certain agents I found to have the power to
shake and pluck back that fleshly vestment, even as a wind might toss
the curtains of a pavilion. For two good reasons, I will not enter
deeply into this scientific branch of my confession. First, because I
have been made to learn that the doom and burthen of our life is bound
for ever on man’s shoulders, and when the attempt is made to cast it
off, it but returns upon us with more unfamiliar and more awful
pressure. Second, because, as my narrative will make, alas! too
evident, my discoveries were incomplete. Enough then, that I not only
recognised my natural body from the mere aura and effulgence of certain
of the powers that made up my spirit, but managed to compound a drug by
which these powers should be dethroned from their supremacy, and a
second form and countenance substituted, none the less natural to me
because they were the expression, and bore the stamp, of lower elements
in my soul.

I hesitated long before I put this theory to the test of practice. I
knew well that I risked death; for any drug that so potently controlled
and shook the very fortress of identity, might, by the least scruple of
an overdose or at the least inopportunity in the moment of exhibition,
utterly blot out that immaterial tabernacle which I looked to it to
change. But the temptation of a discovery so singular and profound at
last overcame the suggestions of alarm. I had long since prepared my
tincture; I purchased at once, from a firm of wholesale chemists, a
large quantity of a particular salt which I knew, from my experiments,
to be the last ingredient required; and late one accursed night, I
compounded the elements, watched them boil and smoke together in the
glass, and when the ebullition had subsided, with a strong glow of
courage, drank off the potion.

The most racking pangs succeeded: a grinding in the bones, deadly
nausea, and a horror of the spirit that cannot be exceeded at the hour
of birth or death. Then these agonies began swiftly to subside, and I
came to myself as if out of a great sickness. There was something
strange in my sensations, something indescribably new and, from its
very novelty, incredibly sweet. I felt younger, lighter, happier in
body; within I was conscious of a heady recklessness, a current of
disordered sensual images running like a millrace in my fancy, a
solution of the bonds of obligation, an unknown but not an innocent
freedom of the soul. I knew myself, at the first breath of this new
life, to be more wicked, tenfold more wicked, sold a slave to my
original evil; and the thought, in that moment, braced and delighted me
like wine. I stretched out my hands, exulting in the freshness of these
sensations; and in the act, I was suddenly aware that I had lost in
stature.

There was no mirror, at that date, in my room; that which stands beside
me as I write, was brought there later on and for the very purpose of
these transformations. The night however, was far gone into the
morning—the morning, black as it was, was nearly ripe for the
conception of the day—the inmates of my house were locked in the most
rigorous hours of slumber; and I determined, flushed as I was with hope
and triumph, to venture in my new shape as far as to my bedroom. I
crossed the yard, wherein the constellations looked down upon me, I
could have thought, with wonder, the first creature of that sort that
their unsleeping vigilance had yet disclosed to them; I stole through
the corridors, a stranger in my own house; and coming to my room, I saw
for the first time the appearance of Edward Hyde.

I must here speak by theory alone, saying not that which I know, but
that which I suppose to be most probable. The evil side of my nature,
to which I had now transferred the stamping efficacy, was less robust
and less developed than the good which I had just deposed. Again, in
the course of my life, which had been, after all, nine tenths a life of
effort, virtue and control, it had been much less exercised and much
less exhausted. And hence, as I think, it came about that Edward Hyde
was so much smaller, slighter and younger than Henry Jekyll. Even as
good shone upon the countenance of the one, evil was written broadly
and plainly on the face of the other. Evil besides (which I must still
believe to be the lethal side of man) had left on that body an imprint
of deformity and decay. And yet when I looked upon that ugly idol in
the glass, I was conscious of no repugnance, rather of a leap of
welcome. This, too, was myself. It seemed natural and human. In my eyes
it bore a livelier image of the spirit, it seemed more express and
single, than the imperfect and divided countenance I had been hitherto
accustomed to call mine. And in so far I was doubtless right. I have
observed that when I wore the semblance of Edward Hyde, none could come
near to me at first without a visible misgiving of the flesh. This, as
I take it, was because all human beings, as we meet them, are
commingled out of good and evil: and Edward Hyde, alone in the ranks of
mankind, was pure evil.

I lingered but a moment at the mirror: the second and conclusive
experiment had yet to be attempted; it yet remained to be seen if I had
lost my identity beyond redemption and must flee before daylight from a
house that was no longer mine; and hurrying back to my cabinet, I once
more prepared and drank the cup, once more suffered the pangs of
dissolution, and came to myself once more with the character, the
stature and the face of Henry Jekyll.

That night I had come to the fatal cross-roads. Had I approached my
discovery in a more noble spirit, had I risked the experiment while
under the empire of generous or pious aspirations, all must have been
otherwise, and from these agonies of death and birth, I had come forth
an angel instead of a fiend. The drug had no discriminating action; it
was neither diabolical nor divine; it but shook the doors of the
prisonhouse of my disposition; and like the captives of Philippi, that
which stood within ran forth. At that time my virtue slumbered; my
evil, kept awake by ambition, was alert and swift to seize the
occasion; and the thing that was projected was Edward Hyde. Hence,
although I had now two characters as well as two appearances, one was
wholly evil, and the other was still the old Henry Jekyll, that
incongruous compound of whose reformation and improvement I had already
learned to despair. The movement was thus wholly toward the worse.

Even at that time, I had not conquered my aversion to the dryness of a
life of study. I would still be merrily disposed at times; and as my
pleasures were (to say the least) undignified, and I was not only well
known and highly considered, but growing towards the elderly man, this
incoherency of my life was daily growing more unwelcome. It was on this
side that my new power tempted me until I fell in slavery. I had but to
drink the cup, to doff at once the body of the noted professor, and to
assume, like a thick cloak, that of Edward Hyde. I smiled at the
notion; it seemed to me at the time to be humourous; and I made my
preparations with the most studious care. I took and furnished that
house in Soho, to which Hyde was tracked by the police; and engaged as
a housekeeper a creature whom I knew well to be silent and
unscrupulous. On the other side, I announced to my servants that a Mr.
Hyde (whom I described) was to have full liberty and power about my
house in the square; and to parry mishaps, I even called and made
myself a familiar object, in my second character. I next drew up that
will to which you so much objected; so that if anything befell me in
the person of Dr. Jekyll, I could enter on that of Edward Hyde without
pecuniary loss. And thus fortified, as I supposed, on every side, I
began to profit by the strange immunities of my position.

Men have before hired bravos to transact their crimes, while their own
person and reputation sat under shelter. I was the first that ever did
so for his pleasures. I was the first that could plod in the public eye
with a load of genial respectability, and in a moment, like a
schoolboy, strip off these lendings and spring headlong into the sea of
liberty. But for me, in my impenetrable mantle, the safety was
complete. Think of it—I did not even exist! Let me but escape into my
laboratory door, give me but a second or two to mix and swallow the
draught that I had always standing ready; and whatever he had done,
Edward Hyde would pass away like the stain of breath upon a mirror; and
there in his stead, quietly at home, trimming the midnight lamp in his
study, a man who could afford to laugh at suspicion, would be Henry
Jekyll.

The pleasures which I made haste to seek in my disguise were, as I have
said, undignified; I would scarce use a harder term. But in the hands
of Edward Hyde, they soon began to turn toward the monstrous. When I
would come back from these excursions, I was often plunged into a kind
of wonder at my vicarious depravity. This familiar that I called out of
my own soul, and sent forth alone to do his good pleasure, was a being
inherently malign and villainous; his every act and thought centered on
self; drinking pleasure with bestial avidity from any degree of torture
to another; relentless like a man of stone. Henry Jekyll stood at times
aghast before the acts of Edward Hyde; but the situation was apart from
ordinary laws, and insidiously relaxed the grasp of conscience. It was
Hyde, after all, and Hyde alone, that was guilty. Jekyll was no worse;
he woke again to his good qualities seemingly unimpaired; he would even
make haste, where it was possible, to undo the evil done by Hyde. And
thus his conscience slumbered.

Into the details of the infamy at which I thus connived (for even now I
can scarce grant that I committed it) I have no design of entering; I
mean but to point out the warnings and the successive steps with which
my chastisement approached. I met with one accident which, as it
brought on no consequence, I shall no more than mention. An act of
cruelty to a child aroused against me the anger of a passer-by, whom I
recognised the other day in the person of your kinsman; the doctor and
the child’s family joined him; there were moments when I feared for my
life; and at last, in order to pacify their too just resentment, Edward
Hyde had to bring them to the door, and pay them in a cheque drawn in
the name of Henry Jekyll. But this danger was easily eliminated from
the future, by opening an account at another bank in the name of Edward
Hyde himself; and when, by sloping my own hand backward, I had supplied
my double with a signature, I thought I sat beyond the reach of fate.

Some two months before the murder of Sir Danvers, I had been out for
one of my adventures, had returned at a late hour, and woke the next
day in bed with somewhat odd sensations. It was in vain I looked about
me; in vain I saw the decent furniture and tall proportions of my room
in the square; in vain that I recognised the pattern of the bed
curtains and the design of the mahogany frame; something still kept
insisting that I was not where I was, that I had not wakened where I
seemed to be, but in the little room in Soho where I was accustomed to
sleep in the body of Edward Hyde. I smiled to myself, and in my
psychological way, began lazily to inquire into the elements of this
illusion, occasionally, even as I did so, dropping back into a
comfortable morning doze. I was still so engaged when, in one of my
more wakeful moments, my eyes fell upon my hand. Now the hand of Henry
Jekyll (as you have often remarked) was professional in shape and size;
it was large, firm, white and comely. But the hand which I now saw,
clearly enough, in the yellow light of a mid-London morning, lying half
shut on the bedclothes, was lean, corded, knuckly, of a dusky pallor
and thickly shaded with a swart growth of hair. It was the hand of
Edward Hyde.

I must have stared upon it for near half a minute, sunk as I was in the
mere stupidity of wonder, before terror woke up in my breast as sudden
and startling as the crash of cymbals; and bounding from my bed I
rushed to the mirror. At the sight that met my eyes, my blood was
changed into something exquisitely thin and icy. Yes, I had gone to bed
Henry Jekyll, I had awakened Edward Hyde. How was this to be explained?
I asked myself; and then, with another bound of terror—how was it to be
remedied? It was well on in the morning; the servants were up; all my
drugs were in the cabinet—a long journey down two pair of stairs,
through the back passage, across the open court and through the
anatomical theatre, from where I was then standing horror-struck. It
might indeed be possible to cover my face; but of what use was that,
when I was unable to conceal the alteration in my stature? And then
with an overpowering sweetness of relief, it came back upon my mind
that the servants were already used to the coming and going of my
second self. I had soon dressed, as well as I was able, in clothes of
my own size: had soon passed through the house, where Bradshaw stared
and drew back at seeing Mr. Hyde at such an hour and in such a strange
array; and ten minutes later, Dr. Jekyll had returned to his own shape
and was sitting down, with a darkened brow, to make a feint of
breakfasting.

Small indeed was my appetite. This inexplicable incident, this reversal
of my previous experience, seemed, like the Babylonian finger on the
wall, to be spelling out the letters of my judgment; and I began to
reflect more seriously than ever before on the issues and possibilities
of my double existence. That part of me which I had the power of
projecting, had lately been much exercised and nourished; it had seemed
to me of late as though the body of Edward Hyde had grown in stature,
as though (when I wore that form) I were conscious of a more generous
tide of blood; and I began to spy a danger that, if this were much
prolonged, the balance of my nature might be permanently overthrown,
the power of voluntary change be forfeited, and the character of Edward
Hyde become irrevocably mine. The power of the drug had not been always
equally displayed. Once, very early in my career, it had totally failed
me; since then I had been obliged on more than one occasion to double,
and once, with infinite risk of death, to treble the amount; and these
rare uncertainties had cast hitherto the sole shadow on my contentment.
Now, however, and in the light of that morning’s accident, I was led to
remark that whereas, in the beginning, the difficulty had been to throw
off the body of Jekyll, it had of late gradually but decidedly
transferred itself to the other side. All things therefore seemed to
point to this; that I was slowly losing hold of my original and better
self, and becoming slowly incorporated with my second and worse.

Between these two, I now felt I had to choose. My two natures had
memory in common, but all other faculties were most unequally shared
between them. Jekyll (who was composite) now with the most sensitive
apprehensions, now with a greedy gusto, projected and shared in the
pleasures and adventures of Hyde; but Hyde was indifferent to Jekyll,
or but remembered him as the mountain bandit remembers the cavern in
which he conceals himself from pursuit. Jekyll had more than a father’s
interest; Hyde had more than a son’s indifference. To cast in my lot
with Jekyll, was to die to those appetites which I had long secretly
indulged and had of late begun to pamper. To cast it in with Hyde, was
to die to a thousand interests and aspirations, and to become, at a
blow and forever, despised and friendless. The bargain might appear
unequal; but there was still another consideration in the scales; for
while Jekyll would suffer smartingly in the fires of abstinence, Hyde
would be not even conscious of all that he had lost. Strange as my
circumstances were, the terms of this debate are as old and commonplace
as man; much the same inducements and alarms cast the die for any
tempted and trembling sinner; and it fell out with me, as it falls with
so vast a majority of my fellows, that I chose the better part and was
found wanting in the strength to keep to it.

Yes, I preferred the elderly and discontented doctor, surrounded by
friends and cherishing honest hopes; and bade a resolute farewell to
the liberty, the comparative youth, the light step, leaping impulses
and secret pleasures, that I had enjoyed in the disguise of Hyde. I
made this choice perhaps with some unconscious reservation, for I
neither gave up the house in Soho, nor destroyed the clothes of Edward
Hyde, which still lay ready in my cabinet. For two months, however, I
was true to my determination; for two months, I led a life of such
severity as I had never before attained to, and enjoyed the
compensations of an approving conscience. But time began at last to
obliterate the freshness of my alarm; the praises of conscience began
to grow into a thing of course; I began to be tortured with throes and
longings, as of Hyde struggling after freedom; and at last, in an hour
of moral weakness, I once again compounded and swallowed the
transforming draught.

I do not suppose that, when a drunkard reasons with himself upon his
vice, he is once out of five hundred times affected by the dangers that
he runs through his brutish, physical insensibility; neither had I,
long as I had considered my position, made enough allowance for the
complete moral insensibility and insensate readiness to evil, which
were the leading characters of Edward Hyde. Yet it was by these that I
was punished. My devil had been long caged, he came out roaring. I was
conscious, even when I took the draught, of a more unbridled, a more
furious propensity to ill. It must have been this, I suppose, that
stirred in my soul that tempest of impatience with which I listened to
the civilities of my unhappy victim; I declare, at least, before God,
no man morally sane could have been guilty of that crime upon so
pitiful a provocation; and that I struck in no more reasonable spirit
than that in which a sick child may break a plaything. But I had
voluntarily stripped myself of all those balancing instincts by which
even the worst of us continues to walk with some degree of steadiness
among temptations; and in my case, to be tempted, however slightly, was
to fall.

Instantly the spirit of hell awoke in me and raged. With a transport of
glee, I mauled the unresisting body, tasting delight from every blow;
and it was not till weariness had begun to succeed, that I was
suddenly, in the top fit of my delirium, struck through the heart by a
cold thrill of terror. A mist dispersed; I saw my life to be forfeit;
and fled from the scene of these excesses, at once glorying and
trembling, my lust of evil gratified and stimulated, my love of life
screwed to the topmost peg. I ran to the house in Soho, and (to make
assurance doubly sure) destroyed my papers; thence I set out through
the lamplit streets, in the same divided ecstasy of mind, gloating on
my crime, light-headedly devising others in the future, and yet still
hastening and still hearkening in my wake for the steps of the avenger.
Hyde had a song upon his lips as he compounded the draught, and as he
drank it, pledged the dead man. The pangs of transformation had not
done tearing him, before Henry Jekyll, with streaming tears of
gratitude and remorse, had fallen upon his knees and lifted his clasped
hands to God. The veil of self-indulgence was rent from head to foot. I
saw my life as a whole: I followed it up from the days of childhood,
when I had walked with my father’s hand, and through the self-denying
toils of my professional life, to arrive again and again, with the same
sense of unreality, at the damned horrors of the evening. I could have
screamed aloud; I sought with tears and prayers to smother down the
crowd of hideous images and sounds with which my memory swarmed against
me; and still, between the petitions, the ugly face of my iniquity
stared into my soul. As the acuteness of this remorse began to die
away, it was succeeded by a sense of joy. The problem of my conduct was
solved. Hyde was thenceforth impossible; whether I would or not, I was
now confined to the better part of my existence; and O, how I rejoiced
to think of it! with what willing humility I embraced anew the
restrictions of natural life! with what sincere renunciation I locked
the door by which I had so often gone and come, and ground the key
under my heel!

The next day, came the news that the murder had not been overlooked,
that the guilt of Hyde was patent to the world, and that the victim was
a man high in public estimation. It was not only a crime, it had been a
tragic folly. I think I was glad to know it; I think I was glad to have
my better impulses thus buttressed and guarded by the terrors of the
scaffold. Jekyll was now my city of refuge; let but Hyde peep out an
instant, and the hands of all men would be raised to take and slay him.

I resolved in my future conduct to redeem the past; and I can say with
honesty that my resolve was fruitful of some good. You know yourself
how earnestly, in the last months of the last year, I laboured to
relieve suffering; you know that much was done for others, and that the
days passed quietly, almost happily for myself. Nor can I truly say
that I wearied of this beneficent and innocent life; I think instead
that I daily enjoyed it more completely; but I was still cursed with my
duality of purpose; and as the first edge of my penitence wore off, the
lower side of me, so long indulged, so recently chained down, began to
growl for licence. Not that I dreamed of resuscitating Hyde; the bare
idea of that would startle me to frenzy: no, it was in my own person
that I was once more tempted to trifle with my conscience; and it was
as an ordinary secret sinner that I at last fell before the assaults of
temptation.

There comes an end to all things; the most capacious measure is filled
at last; and this brief condescension to my evil finally destroyed the
balance of my soul. And yet I was not alarmed; the fall seemed natural,
like a return to the old days before I had made my discovery. It was a
fine, clear, January day, wet under foot where the frost had melted,
but cloudless overhead; and the Regent’s Park was full of winter
chirrupings and sweet with spring odours. I sat in the sun on a bench;
the animal within me licking the chops of memory; the spiritual side a
little drowsed, promising subsequent penitence, but not yet moved to
begin. After all, I reflected, I was like my neighbours; and then I
smiled, comparing myself with other men, comparing my active good-will
with the lazy cruelty of their neglect. And at the very moment of that
vainglorious thought, a qualm came over me, a horrid nausea and the
most deadly shuddering. These passed away, and left me faint; and then
as in its turn faintness subsided, I began to be aware of a change in
the temper of my thoughts, a greater boldness, a contempt of danger, a
solution of the bonds of obligation. I looked down; my clothes hung
formlessly on my shrunken limbs; the hand that lay on my knee was
corded and hairy. I was once more Edward Hyde. A moment before I had
been safe of all men’s respect, wealthy, beloved—the cloth laying for
me in the dining-room at home; and now I was the common quarry of
mankind, hunted, houseless, a known murderer, thrall to the gallows.

My reason wavered, but it did not fail me utterly. I have more than
once observed that in my second character, my faculties seemed
sharpened to a point and my spirits more tensely elastic; thus it came
about that, where Jekyll perhaps might have succumbed, Hyde rose to the
importance of the moment. My drugs were in one of the presses of my
cabinet; how was I to reach them? That was the problem that (crushing
my temples in my hands) I set myself to solve. The laboratory door I
had closed. If I sought to enter by the house, my own servants would
consign me to the gallows. I saw I must employ another hand, and
thought of Lanyon. How was he to be reached? how persuaded? Supposing
that I escaped capture in the streets, how was I to make my way into
his presence? and how should I, an unknown and displeasing visitor,
prevail on the famous physician to rifle the study of his colleague,
Dr. Jekyll? Then I remembered that of my original character, one part
remained to me: I could write my own hand; and once I had conceived
that kindling spark, the way that I must follow became lighted up from
end to end.

Thereupon, I arranged my clothes as best I could, and summoning a
passing hansom, drove to an hotel in Portland Street, the name of which
I chanced to remember. At my appearance (which was indeed comical
enough, however tragic a fate these garments covered) the driver could
not conceal his mirth. I gnashed my teeth upon him with a gust of
devilish fury; and the smile withered from his face—happily for him—yet
more happily for myself, for in another instant I had certainly dragged
him from his perch. At the inn, as I entered, I looked about me with so
black a countenance as made the attendants tremble; not a look did they
exchange in my presence; but obsequiously took my orders, led me to a
private room, and brought me wherewithal to write. Hyde in danger of
his life was a creature new to me; shaken with inordinate anger, strung
to the pitch of murder, lusting to inflict pain. Yet the creature was
astute; mastered his fury with a great effort of the will; composed his
two important letters, one to Lanyon and one to Poole; and that he
might receive actual evidence of their being posted, sent them out with
directions that they should be registered. Thenceforward, he sat all
day over the fire in the private room, gnawing his nails; there he
dined, sitting alone with his fears, the waiter visibly quailing before
his eye; and thence, when the night was fully come, he set forth in the
corner of a closed cab, and was driven to and fro about the streets of
the city. He, I say—I cannot say, I. That child of Hell had nothing
human; nothing lived in him but fear and hatred. And when at last,
thinking the driver had begun to grow suspicious, he discharged the cab
and ventured on foot, attired in his misfitting clothes, an object
marked out for observation, into the midst of the nocturnal passengers,
these two base passions raged within him like a tempest. He walked
fast, hunted by his fears, chattering to himself, skulking through the
less frequented thoroughfares, counting the minutes that still divided
him from midnight. Once a woman spoke to him, offering, I think, a box
of lights. He smote her in the face, and she fled.

When I came to myself at Lanyon’s, the horror of my old friend perhaps
affected me somewhat: I do not know; it was at least but a drop in the
sea to the abhorrence with which I looked back upon these hours. A
change had come over me. It was no longer the fear of the gallows, it
was the horror of being Hyde that racked me. I received Lanyon’s
condemnation partly in a dream; it was partly in a dream that I came
home to my own house and got into bed. I slept after the prostration of
the day, with a stringent and profound slumber which not even the
nightmares that wrung me could avail to break. I awoke in the morning
shaken, weakened, but refreshed. I still hated and feared the thought
of the brute that slept within me, and I had not of course forgotten
the appalling dangers of the day before; but I was once more at home,
in my own house and close to my drugs; and gratitude for my escape
shone so strong in my soul that it almost rivalled the brightness of
hope.

I was stepping leisurely across the court after breakfast, drinking the
chill of the air with pleasure, when I was seized again with those
indescribable sensations that heralded the change; and I had but the
time to gain the shelter of my cabinet, before I was once again raging
and freezing with the passions of Hyde. It took on this occasion a
double dose to recall me to myself; and alas! six hours after, as I sat
looking sadly in the fire, the pangs returned, and the drug had to be
re-administered. In short, from that day forth it seemed only by a
great effort as of gymnastics, and only under the immediate stimulation
of the drug, that I was able to wear the countenance of Jekyll. At all
hours of the day and night, I would be taken with the premonitory
shudder; above all, if I slept, or even dozed for a moment in my chair,
it was always as Hyde that I awakened. Under the strain of this
continually impending doom and by the sleeplessness to which I now
condemned myself, ay, even beyond what I had thought possible to man, I
became, in my own person, a creature eaten up and emptied by fever,
languidly weak both in body and mind, and solely occupied by one
thought: the horror of my other self. But when I slept, or when the
virtue of the medicine wore off, I would leap almost without transition
(for the pangs of transformation grew daily less marked) into the
possession of a fancy brimming with images of terror, a soul boiling
with causeless hatreds, and a body that seemed not strong enough to
contain the raging energies of life. The powers of Hyde seemed to have
grown with the sickliness of Jekyll. And certainly the hate that now
divided them was equal on each side. With Jekyll, it was a thing of
vital instinct. He had now seen the full deformity of that creature
that shared with him some of the phenomena of consciousness, and was
co-heir with him to death: and beyond these links of community, which
in themselves made the most poignant part of his distress, he thought
of Hyde, for all his energy of life, as of something not only hellish
but inorganic. This was the shocking thing; that the slime of the pit
seemed to utter cries and voices; that the amorphous dust gesticulated
and sinned; that what was dead, and had no shape, should usurp the
offices of life. And this again, that that insurgent horror was knit to
him closer than a wife, closer than an eye; lay caged in his flesh,
where he heard it mutter and felt it struggle to be born; and at every
hour of weakness, and in the confidence of slumber, prevailed against
him, and deposed him out of life. The hatred of Hyde for Jekyll was of
a different order. His terror of the gallows drove him continually to
commit temporary suicide, and return to his subordinate station of a
part instead of a person; but he loathed the necessity, he loathed the
despondency into which Jekyll was now fallen, and he resented the
dislike with which he was himself regarded. Hence the ape-like tricks
that he would play me, scrawling in my own hand blasphemies on the
pages of my books, burning the letters and destroying the portrait of
my father; and indeed, had it not been for his fear of death, he would
long ago have ruined himself in order to involve me in the ruin. But
his love of life is wonderful; I go further: I, who sicken and freeze at
the mere thought of him, when I recall the abjection and passion of
this attachment, and when I know how he fears my power to cut him off
by suicide, I find it in my heart to pity him.

It is useless, and the time awfully fails me, to prolong this
description; no one has ever suffered such torments, let that suffice;
and yet even to these, habit brought—no, not alleviation—but a certain
callousness of soul, a certain acquiescence of despair; and my
punishment might have gone on for years, but for the last calamity
which has now fallen, and which has finally severed me from my own face
and nature. My provision of the salt, which had never been renewed
since the date of the first experiment, began to run low. I sent out
for a fresh supply and mixed the draught; the ebullition followed, and
the first change of colour, not the second; I drank it and it was
without efficiency. You will learn from Poole how I have had London
ransacked; it was in vain; and I am now persuaded that my first supply
was impure, and that it was that unknown impurity which lent efficacy
to the draught.

About a week has passed, and I am now finishing this statement under
the influence of the last of the old powders. This, then, is the last
time, short of a miracle, that Henry Jekyll can think his own thoughts
or see his own face (now how sadly altered!) in the glass. Nor must I
delay too long to bring my writing to an end; for if my narrative has
hitherto escaped destruction, it has been by a combination of great
prudence and great good luck. Should the throes of change take me in
the act of writing it, Hyde will tear it in pieces; but if some time
shall have elapsed after I have laid it by, his wonderful selfishness
and circumscription to the moment will probably save it once again from
the action of his ape-like spite. And indeed the doom that is closing
on us both has already changed and crushed him. Half an hour from now,
when I shall again and forever reindue that hated personality, I know
how I shall sit shuddering and weeping in my chair, or continue, with
the most strained and fearstruck ecstasy of listening, to pace up and
down this room (my last earthly refuge) and give ear to every sound of
menace. Will Hyde die upon the scaffold? or will he find courage to
release himself at the last moment? God knows; I am careless; this is
my true hour of death, and what is to follow concerns another than
myself. Here then, as I lay down the pen and proceed to seal up my
confession, I bring the life of that unhappy Henry Jekyll to an end.
