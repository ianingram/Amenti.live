/* Amenti.live/amenti-voice.js · 2026-10-04 03:30 UTC */
/* ████████████████████████████████████████████████████████████████████████████
   ██                                                                        ██
   ██   WATCHED FILE — amenti-voice.js                                       ██
   ██   THIS IS THE VOICE PLATFORM. PAGE1 SPEAKS THROUGH IT.                 ██
   ██                                                                        ██
   ████████████████████████████████████████████████████████████████████████████

   YOU MAY EDIT THIS FILE. That is not what this notice is about.

   On 20 August 2026 this file was REPLACED, in full, with the contents of
   VOICE.json. 644 lines of engine became 1,624 lines of JSON. The commit was
   signed and Verified and its message read "Update print statement from
   'Hello' to 'Goodbye'". Nothing complained. It was found forty minutes later
   by somebody opening the file.

   Every line of the header below was overwritten too. A warning only works on
   somebody who is reading, so the real guard is not this banner:

       probes/probe-engine.mjs   ·   .github/workflows/guard.yml

   It runs on every push that touches this file and hourly at :12. It fails the
   build — loudly, within about a minute — if this file stops being itself:

       · stops parsing as JavaScript
       · loses  PROFILES        the chunk profiles ARE the cache namespace
       · loses  stopReading     the brake; all three facades hang off it
       · loses  composeStyle    STYLE is an input to the /speak cache key
       · loses  speak()         the one entry point every facade calls
       · loses  Amenti.throttle / Amenti.conversation   the facades
       · falls below 400 lines  a real edit does not halve a file; a paste does

   IF THE GUARD GOES RED, DO NOT RETYPE THIS FILE. Recover it:
       History → the last good commit → the BLOB view, NOT the diff view
       → Raw → select all → paste over the current contents.
   A diff view cannot produce a usable file. Two pastes failed that way on the
   night this notice was written.

   AND REBUILD THE BUNDLE. Page1 loads amenti-core.bundle.js, not this file.
   Repairing the source and leaving the bundle stale changes nothing on the
   surface, and the guard checks both for exactly that reason.

   ────────────────────────────────────────────────────────────────────────────
   The file's own header begins below. It is older than this notice and it
   explains WHY the engine is shaped as it is; this notice only explains what
   happens if it stops being shaped that way.
   ══════════════════════════════════════════════════════════════════════════ *//* ============================================================================
   amenti-voice.js  ·  Ingram Manor LLC
   THE VOICE PLATFORM — one TTS engine, one chunker, one cache key.
   ----------------------------------------------------------------------------
   WHAT THIS REPLACES, AND WHY IT HAD TO

   Four copies of one engine were running, all POSTing the same { text, style,
   voice } to the same /speak:

     library.js (~494)       reading room        chunk 320   own VOICE_WORKER
     amenti-throttle.js      Page1 buttons       chunk 320   the "mother ship"
     AMENTI_VOICE (Page1)    THE COUNSEL         no chunking, NO stop()
     Page2.html (~16893)     Gabriel             chunk 700/1100

   The Worker keys every clip:

       audioKey = sha256(TTS_MODEL + voice + STYLE + TEXT)

   TEXT is in the key. So the chunk boundaries ARE the cache key — and a 320-char
   chunk and a 700-char chunk of the same essay hash differently. The reading
   room and Page2 share NOTHING. The archive is being rendered more than once
   and no invoice ever says so.

   STYLE is in the key too. Which is why composeStyle / VOICE_REGISTER /
   PACE_DIRECTION / chunkText / plainText below are copied BYTE-FOR-BYTE from the
   deployed reading room. Not improved. Not tidied. Not reformatted. A prettier
   string re-renders the whole archive and re-bills it.

   TWO REGISTERS, AND THEY MUST NOT MIX
     RECITAL        composeStyle(). The archive. CACHED. Never varies. Locked.
     CONVERSATIONAL The counsel. Unique text every turn, so it never hits the
                    cache anyway — which is exactly why the per-move instrument
                    panel (warm/cool/sharp/grave/danger/humour) is FREE here and
                    FORBIDDEN on the recital path.

   MIGRATION IS OPT-IN, PER SURFACE, BECAUSE IT HAS A BILL ATTACHED
   Changing a surface's chunk size orphans that surface's cached audio. So the
   chunker is a PROFILE, and each surface keeps its own until you decide to
   re-render on purpose. Consolidating the CODE is free; consolidating the CACHE
   KEY is not, and the two are separable. Do the free one now.

   FACADES: Amenti.throttle.* and window.AMENTI_VOICE.* keep working, unchanged,
   over this core. Nothing is renamed until every caller has been grepped.
   ============================================================================ */
(function () {
  'use strict';
  var Amenti = (window.Amenti = window.Amenti || {});
  if (Amenti.voice && Amenti.voice.__v) return;   // include-once guard

  /* ---- config / constants (LOCKED — identical to deployed reading room) ---- */
  var VOICE_WORKER       = 'https://amenti-proxy.ingram-ian.workers.dev/speak';
  var VOICE_REGISTER     = 'Read clearly, in a measured, dignified tone';
  var VOICE_NAME_DEFAULT = 'Kore';
  var CHUNK_MAX       = 320;   // LOCKED — the reading room + Page1. Do not change.

  /* Chunk PROFILES. Each surface's boundaries are part of its cache key, so a
     surface keeps its own profile until it is deliberately re-rendered.
       recital : 320   — the reading room, Page1, and the existing archive
       gabriel : 700   — Page2's engine, as deployed
     Unify these ONLY when you are willing to pay to regenerate the audio. */
  var PROFILES = { recital: 320, gabriel: 700, counsel: 320 };
  var CHUNK_LOOKAHEAD = 2;
  var CHUNK_TIMEOUT   = 60000;
  var START_TIMEOUT   = 40000;

  /* ── THE FAST OPENING MEASURE ─────────────────────────────────────────────
     CONVERSATIONAL ONLY. FORBIDDEN ON THE RECITAL PATH.

     The counsel's text is unique every turn and NEVER hits the archive, so its
     chunk boundaries are FREE to move. The recital's boundaries ARE the cache
     key — move them and every clip in R2 is orphaned. Same law as the register:
     free here, forbidden there.

     probe20 measured the engine on live hardware:

         render_ms  =  7510  +  18.25 x chars          (R2 miss, one measure)

     So the mouth opens sooner if the FIRST measure is short:

         320-char opener ....... 13.0 s
         110-char opener ........ 9.5 s
          80-char opener ........ 9.0 s
           the floor ............ 7.5 s

     It cannot go arbitrarily small. Measure 2 (320 chars) lands at ~13.3s, and
     an opener of C chars plays for roughly C/15 seconds. Below ~70 chars the
     opener finishes speaking before measure 2 arrives and the voice STUTTERS.
     110 is the floor plus margin.

     Do not "unify" this with CHUNK_MAX. It is a different register with a
     different bill. See fleet-semantics. */
  var CONV_FIRST_MAX = 110;

  var RATE_FAST = 1.0;
  var RATE_SLOW = 1.0;
  var REST_SOFT     = 0.16;
  var REST_SENTENCE = 0.38;
  var REST_PARA     = 0.85;
  var PACE_DIRECTION = 'Speak at a brisk, lively, natural pace, as a person speaking energetically — not slow or ponderous';

  var READ_ALOUD = '\ud83d\udd0a Read aloud';
  var READ_STOP  = '\u23f9 Stop';
  var READ_RETRY = '\u21bb Retry';

  var voicePlayer = null;
  var audioCtx = null;

  var voiceGain = null;

  function getAudioCtx() {
    if (!audioCtx) {
      var Ctx = window.AudioContext || window.webkitAudioContext;
      audioCtx = new Ctx();
    }
    if (audioCtx.state === 'suspended') { try { audioCtx.resume(); } catch (e) {} }
    return audioCtx;
  }

  /* ---- THE VOICE BUS --------------------------------------------------------
     Every voice source used to connect straight to ctx.destination, which meant
     there was no single place to hold the speech and therefore NOTHING FOR A
     SCORE OR A BED TO DUCK AGAINST. Anything playing underneath would have had
     to compete rather than yield.

     One gain node now sits between the sources and the destination. It stays at
     1 forever unless something asks otherwise, so with nothing else playing the
     audio path is identical to what it was.

     ADDITIVE AND INERT. No symbol removed, no cache key touched, no chunk
     boundary moved. getVoiceBus() is exposed so a sound layer can read the
     context and duck the bus; if nobody calls it, nothing changes. */
  function getVoiceBus() {
    var ctx = getAudioCtx();
    if (!voiceGain) {
      voiceGain = ctx.createGain();
      voiceGain.gain.value = 1;
      voiceGain.connect(ctx.destination);
    }
    return voiceGain;
  }

  /* ---- Embodiment: resolve a figure's voice from the published roster ------ */
  /* THE SHEET IS NOT READ AT RUNTIME (2 Oct 2026). It is where the ledger is
     edited; names.csv is what ships. See loadRoster. */
  var rosterPromise = null;

  /* ── AN UNRESOLVED FIGURE MUST NOT SOUND LIKE A DECISION ─────────────────
     This returned VOICE_NAME_DEFAULT — 'Kore', a FEMALE voice — for anything
     it could not resolve. So a roster that failed to load sounded exactly like
     a roster that had loaded and said every figure was a woman.

     ABRAHAM LINCOLN SPOKE IN A WOMAN'S VOICE and nothing anywhere said why:
     the only trace was a console.warn nobody was watching, and the product
     carried on sounding deliberate.

     A FALLBACK THAT LOOKS LIKE A CHOICE IS THE SILENT SIGNATURE. It is the
     same shape as `sealed: 1`, as the cron set to Sunday, as a green tick with
     no probe behind it.

     It still has to say SOMETHING — going mute would be worse — but it now
     says so out loud, once per figure, naming who could not be resolved. */
  var warnedVoice = {};
  function baseVoiceFor(gender, who) {
    var g = String(gender || '').toLowerCase();
    if (g.charAt(0) === 'm') return 'Charon';
    if (g.charAt(0) === 'f') return 'Kore';
    var name = String(who || '').trim();
    if (name && !warnedVoice[name]) {
      warnedVoice[name] = true;
      console.warn('amenti-voice: NO GENDER RESOLVED for "' + name + '" — falling back to ' +
                   VOICE_NAME_DEFAULT + '. Either the roster did not load, or that row has no ' +
                   'Gender. The figure will not sound like themselves until it does.');
    }
    return VOICE_NAME_DEFAULT;
  }
  /* ── THE CONVERSATIONAL REGISTER ─────────────────────────────────────────
     The Terminal talks WITH you; it does not recite AT you. Separate register,
     separate cache space, and — because its text is unique every turn — a place
     where prosody may vary per utterance at no cost.

     THE INSTRUMENT PANEL. Tone is not decoration; a shift in temperature is a
     PROBE. Bound to the figure and not the utterance, every register collapses
     into one voice and the probe returns nothing.
     ──────────────────────────────────────────────────────────────────────── */
  var CONV_REGISTER = 'Say the following in a clear, natural, conversational voice';

  /* THE REGISTERS LIVE IN amenti-doctrine.js. ONE COPY.
     They were duplicated here AND in Page1's AMENTI_VOICE — byte-identical, kept
     in step BY HAND, with nothing enforcing it. That is composeStyle again, and
     it is the exact disease probe7 exists to prevent. The fallback below is for
     a surface that has not loaded the doctrine; it is not a second source. */
  function REG() {
    var d = window.Amenti && window.Amenti.doctrine;
    return (d && d.REGISTERS) || {
      warm:   'Speak gently, unhurried, with evident care.',
      cool:   'Speak with clinical distance, level and unhurried.',
      sharp:  'Speak with sudden edge — clipped, direct, harder than before.',
      grave:  'Speak slowly and heavily, as one who has paid for what he says.',
      danger: 'Speak quietly, and let the quiet be worse than shouting.',
      humour: 'Let there be dry amusement in the voice, and something rueful under it.'
    };
  }

  /* The conversational style. NEVER call this for the archive. */
  function composeConversational(fig, move) {
    var s = CONV_REGISTER;
    if (fig && fig.dialect) s += '. Accent and dialect: ' + String(fig.dialect).trim();
    if (fig && fig.voice)   s += '. Voice character: ' + String(fig.voice).trim();
    s += '. ' + PACE_DIRECTION;
    var reg = move && REG()[move];
    if (reg) s += ' ' + reg;
    return s;
  }

  /* ⚠ LOCKED — byte-for-byte from the deployed reading room. This string is
     part of the /speak cache key. Changing it orphans the entire archive. */
  function composeStyle(fig) {
    var s = VOICE_REGISTER;
    if (fig && fig.dialect) s += '. Accent and dialect: ' + fig.dialect;
    if (fig && fig.voice)   s += '. Voice character: ' + fig.voice;
    s += '. ' + PACE_DIRECTION;
    return s;
  }
  function parseCsv(text) {
    var rows = [], row = [], field = '', inQ = false;
    for (var i = 0; i < text.length; i++) {
      var c = text[i];
      if (inQ) {
        if (c === '"') { if (text[i + 1] === '"') { field += '"'; i++; } else inQ = false; }
        else field += c;
      } else {
        if (c === '"') inQ = true;
        else if (c === ',') { row.push(field); field = ''; }
        else if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; }
        else if (c === '\r') { /* ignore */ }
        else field += c;
      }
    }
    if (field.length || row.length) { row.push(field); rows.push(row); }
    if (!rows.length) return [];
    var header = rows[0].map(function (h) { return h.trim(); });
    var out = [];
    for (var r = 1; r < rows.length; r++) {
      if (rows[r].length === 1 && rows[r][0] === '') continue;
      var obj = {};
      for (var k = 0; k < header.length; k++) obj[header[k]] = (rows[r][k] || '').trim();
      out.push(obj);
    }
    return out;
  }
  function rowToFigure(row) {
    var name = row['Full Name'] || row['Name'] || '';
    if (!name) return null;
    return {
      key: name.toLowerCase().trim(),
      name: name,
      gender: row['Gender'] || '',
      dialect: row['Dialect'] || '',
      voice: row['Voice'] || ''
    };
  }
  /* ── LOCAL FIRST, THE SHEET SECOND · FOUND ON GLASS 28 AUG 2026 ──────────
     This went straight to the Google Sheet and had nothing to fall back on.
     On 28 Aug that fetch threw "Load failed" from the page — and because an
     unresolved figure falls back to Kore, ABRAHAM LINCOLN SPOKE IN A WOMAN'S
     VOICE with nothing anywhere saying why.

     THE FLAGSHIP HAD ALREADY SOLVED THIS AND THIS FILE DID NOT KNOW. Page1
     logs its own load as "via ./names.csv (local, first)" and then "via the
     sheet (authoritative)" — it reads the committed copy, then upgrades when
     the network allows. Same repo, same columns, same 1,011 rows, sitting
     there unfetched by the one module whose whole job depends on them.

     TWO REGISTERS OF ONE THING, AND ONLY ONE OF THEM KNEW HOW TO SURVIVE.

     The local file is committed beside the code, so it cannot fail for a
     network reason. (The sheet upgrade described here was REMOVED on 2 Oct
     2026 — names.csv is now the only runtime source. See loadRoster.) */
  /* ── BESIDE THE ENGINE, NOT BESIDE THE PAGE · FOUND 2 OCT 2026 ──────────
     './names.csv' resolved against the PAGE. On Page1 that is the same
     folder as the engine, so it worked. On Amenti-Studios/dracula/ it is a
     404 — and on the same day the published sheet stopped answering, so BOTH
     sources failed and Darwin and the Count read episode one in Kore.
     Episode one's first hearing was the Lincoln failure again, on a new page.

     The roster is the engine's data, so it resolves against the ENGINE'S OWN
     URL: document.currentScript while this file executes (it is the bundle
     when bundled). On Page1 that is the identical file as before. Anywhere
     else that loads the engine, it is the same names.csv Page1 reads.
     No voice, no style, no cache key moves — only where the CSV is fetched. */
  var LOCAL_CSV = (function () {
    try {
      var s = document.currentScript;
      if (s && s.src) return new URL('names.csv', s.src).href;
    } catch (e) {}
    return './names.csv';
  })();

  function fromCsv(text) {
    var map = {};
    parseCsv(text).forEach(function (row) { var f = rowToFigure(row); if (f) map[f.key] = f; });
    return map;
  }

  function fetchCsv(url) {
    return fetch(url, { cache: 'no-store' }).then(function (r) {
      if (!r.ok) throw new Error(url + ' → HTTP ' + r.status);
      return r.text();
    }).then(function (t) {
      var m = fromCsv(t);
      if (!Object.keys(m).length) throw new Error(url + ' → parsed to nothing');
      return m;
    });
  }

  /* ── ONE RUNTIME SOURCE: names.csv · 2 OCT 2026 ─────────────────────────
     The Google Sheet is the production copy — where the ledger is edited —
     and names.csv is what the site reads. This used to read names.csv and
     then let the sheet OVERWRITE it whenever the sheet answered, so the
     roster depended on Google after all, and the two could disagree mid-
     session. On 2 Oct the published sheet returned a login page instead of
     CSV. It is no longer fetched here. Edit the sheet, export names.csv,
     commit it; that commit is the release.

     If names.csv does not load, EVERY figure loses their voice at once, so
     that is said as loudly as this file can say anything. */
  function loadRoster() {
    if (rosterPromise) return rosterPromise;
    rosterPromise = fetchCsv(LOCAL_CSV).then(function (local) {
      console.log('amenti-voice: roster ' + Object.keys(local).length +
                  ' figures via ' + LOCAL_CSV);
      return local;
    })['catch'](function (e) {
      console.error('amenti-voice: THE ROSTER DID NOT LOAD — ' + LOCAL_CSV + ' (' +
                    (e && e.message) + ').\nEVERY FIGURE WILL NOW SPEAK IN THE DEFAULT VOICE (' +
                    VOICE_NAME_DEFAULT + '). This is not a style; it is a failure.');
      return {};
    });
    return rosterPromise;
  }

  function resolveVoice(name) {
    return loadRoster().then(function (map) {
      /* THE LOOKUP IS UNCHANGED, DELIBERATELY. A surname fallback was written
         here on 28 Aug and REMOVED before it shipped: the cache key is
         sha256(model + VOICE + style + text), so changing which voice a name
         resolves to ORPHANS every clip already rendered for it. That is real
         spend, for a fault nobody had confirmed — every known caller passes
         the full name. The warning below names the failure; when a real
         mismatch is found, THEN change this, knowing what it costs. */
      var fig = map[String(name || '').toLowerCase().trim()];
      return { voice: baseVoiceFor(fig && fig.gender, name), style: composeStyle(fig), figure: fig || null };
    });
  }

  function decodeAudio(ctx, bytes) {
    return new Promise(function (resolve, reject) {
      var p;
      try { p = ctx.decodeAudioData(bytes, resolve, reject); }
      catch (e) { reject(e); return; }
      if (p && typeof p.then === 'function') p.then(resolve, reject);
    });
  }

  /* ---- canonical strip (LOCKED) -------------------------------------------- */
  function plainText(md) {
    return String(md || '')
      .replace(/\r\n?/g, '\n')
      .replace(/^#+\s*/gm, '')
      .replace(/\*\*([^*]+)\*\*/g, '$1')
      .replace(/__([^_]+)__/g, '$1')
      .replace(/\*([^*]+)\*/g, '$1')
      .replace(/_([^_]+)_/g, '$1')
      .replace(/^\s*[-*]\s+/gm, '')
      .replace(/[ \t]+/g, ' ')
      .replace(/\n{3,}/g, '\n\n')
      .replace(/[ \t]*\n[ \t]*/g, '\n')
      .trim();
  }

  /* ---- cadence + deterministic chunker (LOCKED) ---------------------------- */
  function restFor(chunkTextStr, endsParagraph) {
    if (endsParagraph) return REST_PARA;
    var last = chunkTextStr.replace(/["')\]\u201d\u2019]+$/, '').slice(-1);
    if (last === '.' || last === '!' || last === '?') return REST_SENTENCE;
    if (last === ',' || last === ';' || last === ':' || last === '\u2014' || last === '-') return REST_SOFT;
    return REST_SENTENCE;
  }
  function splitSentences(text) {
    var parts = String(text).match(/[^.!?]+[.!?]+[)\]"'\u201d\u2019]*\s*|[^.!?]+$/g);
    if (!parts) { var t = String(text).trim(); return t ? [t] : []; }
    var out = [];
    for (var i = 0; i < parts.length; i++) { var s = parts[i].trim(); if (s) out.push(s); }
    return out;
  }
  function hardSplit(sentence, maxChars) {
    var words = sentence.split(/\s+/), out = [], cur = '';
    for (var i = 0; i < words.length; i++) {
      var w = words[i];
      if (cur && cur.length + 1 + w.length > maxChars) { out.push(cur); cur = w; }
      else cur = cur ? cur + ' ' + w : w;
    }
    if (cur) out.push(cur);
    return out;
  }
  function chunkText(text, maxChars) {
    var paragraphs = String(text).split(/\n{2,}/);
    var chunks = [];
    for (var p = 0; p < paragraphs.length; p++) {
      var para = paragraphs[p].replace(/\n/g, ' ').trim();
      if (!para) continue;
      var sentences = splitSentences(para), pieces = [], cur = '';
      for (var i = 0; i < sentences.length; i++) {
        var s = sentences[i];
        if (s.length > maxChars) {
          if (cur) { pieces.push(cur); cur = ''; }
          var hs = hardSplit(s, maxChars);
          for (var j = 0; j < hs.length; j++) pieces.push(hs[j]);
          continue;
        }
        if (cur && cur.length + 1 + s.length > maxChars) { pieces.push(cur); cur = s; }
        else cur = cur ? cur + ' ' + s : s;
      }
      if (cur) pieces.push(cur);
      for (var k = 0; k < pieces.length; k++) {
        var endsPara = (k === pieces.length - 1);
        chunks.push({ text: pieces[k], rest: restFor(pieces[k], endsPara), rate: endsPara ? RATE_SLOW : RATE_FAST });
      }
    }
    return chunks;
  }

  /* ⚠ CONVERSATIONAL ONLY. Never call this for the archive.
     It does not re-implement the chunker — it CALLS the locked one and re-cuts
     ONLY the opening measure. chunkText below is untouched, byte for byte,
     because its boundaries are the cache key. A second copy of a chunker is how
     an archive forks.

     ONLY THE OPENER IS SHORT. Every measure pays the same ~7.5s render floor,
     so cutting the whole reply into small pieces would buy a fast start and then
     pay the floor over and over — more requests, more cost, and a voice that can
     run dry between them. So: one short opener, then the remainder rejoined, then
     the rest of the reply at its normal 320. */
  function chunkConversational(text, maxChars, firstMax) {
    var all = chunkText(text, maxChars);
    if (!all.length || !firstMax || firstMax >= maxChars) return all;

    var head = all[0];
    if (head.text.length <= firstMax) return all;      // already short enough

    var cut = chunkText(head.text, firstMax);
    if (cut.length < 2) return all;                    // one sentence, too long to cut

    var opener = cut[0];
    var remainder = [];
    for (var i = 1; i < cut.length; i++) remainder.push(cut[i].text);

    /* The opener ends a breath, not a paragraph. chunkText would have given the
       last piece a full paragraph rest; that would put a long silence in the
       middle of the figure's first sentence. */
    opener.rest = restFor(opener.text, false);
    opener.rate = RATE_FAST;

    var rejoined = { text: remainder.join(' '), rest: head.rest, rate: head.rate };

    return [opener, rejoined].concat(all.slice(1));
  }

  /* ---- engine: fetch, schedule, watchdog (verbatim) ------------------------ */
  /* ── THE WARM SHELF · 3 OCT 2026 ─────────────────────────────────────────
     A reading used to ask for its next line only when the last one had
     finished, so every cue started with a full render wait — 6 to 12 seconds
     of silence between lines on a first play. warm() lets a caller fetch the
     NEXT text while the current one plays; the bytes wait here and the real
     speak() takes them instead of fetching again.

     THE KEY IS UNTOUCHED. Nothing here changes what is sent to /speak — warm()
     sends the identical text, style and voice speak() would, so the Worker
     stores the identical R2 entry. The shelf is only a short-lived copy in
     memory, keyed the same way, so the second request never happens.
     Bounded: SHELF_MAX entries, oldest dropped. A failed warm leaves nothing
     on the shelf, so the real request simply fetches as it always did. */
  var SHELF_MAX = 12;
  var shelf = {}, shelfOrder = [];
  function shelfKey(chunk, style, voice) {
    return voice + '\n' + style + '\n' + ((chunk && chunk.text != null) ? chunk.text : chunk);
  }
  function shelfPut(k, p) {
    shelf[k] = p; shelfOrder.push(k);
    while (shelfOrder.length > SHELF_MAX) { delete shelf[shelfOrder.shift()]; }
    p.then(null, function () { if (shelf[k] === p) delete shelf[k]; });
  }

  function fetchChunkBytes(chunk, style, voice, signal) {
    var k = shelfKey(chunk, style, voice);
    if (shelf[k]) {
      /* decodeAudioData detaches the buffer it is given, so hand out a copy
         and keep the original on the shelf for a replay. */
      return shelf[k].then(function (buf) { return buf.slice(0); });
    }
    return fetchChunkBytesLive(chunk, style, voice, signal);
  }

  function fetchChunkBytesLive(chunk, style, voice, signal) {
    var attempts = 0;
    function go() {
      var ctrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
      var timer = null, onAbort = null;
      function cleanup() {
        if (timer) { clearTimeout(timer); timer = null; }
        if (signal && onAbort) { try { signal.removeEventListener('abort', onAbort); } catch (e) {} onAbort = null; }
      }
      if (ctrl) {
        timer = setTimeout(function () { try { ctrl.abort(); } catch (e) {} }, CHUNK_TIMEOUT);
        if (signal) {
          if (signal.aborted) { try { ctrl.abort(); } catch (e) {} }
          else { onAbort = function () { try { ctrl.abort(); } catch (e) {} }; try { signal.addEventListener('abort', onAbort); } catch (e) {} }
        }
      }
      return fetch(VOICE_WORKER, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: (chunk && chunk.text != null) ? chunk.text : chunk, style: style, voice: voice }),
        signal: ctrl ? ctrl.signal : signal
      }).then(function (r) {
        if (r.ok) return r.arrayBuffer();
        return r.json().then(function (j) { return j; }, function () { return null; })
          .then(function (j) {
            var msg = (j && j.error) || ('voice ' + r.status);
            if (msg === 'no_audio' && attempts < 2) { attempts++; cleanup(); return go(); }
            throw new Error(msg);
          });
      }).then(
        function (out) { cleanup(); return out; },
        function (err) { cleanup(); throw err; }
      );
    }
    return go();
  }

  function clearWatchdog(p) { if (p && p.watchdog) { clearTimeout(p.watchdog); p.watchdog = null; } }

  function stopReading() {
    var p = voicePlayer;
    voicePlayer = null;
    if (!p) return;
    p.cancelled = true;
    clearWatchdog(p);
    if (p.abort) { try { p.abort.abort(); } catch (e) {} }
    for (var i = 0; i < p.sources.length; i++) {
      try { p.sources[i].onended = null; p.sources[i].stop(); } catch (e) {}
    }
    p.sources = [];
    if (p.btn) { p.btn.textContent = READ_ALOUD; p.btn.disabled = false; }
  }

  function failStart(p) {
    if (!p || p.cancelled) return;
    p.cancelled = true;
    clearWatchdog(p);
    if (p.abort) { try { p.abort.abort(); } catch (e) {} }
    for (var i = 0; i < p.sources.length; i++) {
      try { p.sources[i].onended = null; p.sources[i].stop(); } catch (e) {}
    }
    p.sources = [];
    if (voicePlayer === p) voicePlayer = null;
    if (p.btn) { p.btn.textContent = READ_RETRY; p.btn.disabled = false; }
    if (p.onFail) { try { p.onFail('no audio after ' + START_TIMEOUT + 'ms'); } catch (e) {} }
  }

  /* ── onFail · 3 OCT 2026 ───────────────────────────────────────────────────
     onDone fires only on a NATURAL finish. A line that failed to render used
     to end in silence with no callback at all, so anything waiting on it —
     a cue sheet, a play-all — waited forever with nothing on screen. That is
     how Dracula episode one stopped after its first cue. onFail is the other
     half: the caller is now told, and can retry or say so. Optional and
     additive; a caller that passes nothing behaves exactly as before. */
  function startReading(text, btn, style, voice, onDone, max, firstMax, onFail) {
    max = max || CHUNK_MAX;      // the surface's chunk PROFILE — part of its cache key
    var ctx;
    try { ctx = getAudioCtx(); }
    catch (e) {
      console.error('Throttle: audio unavailable:', e && e.message);
      if (btn) { btn.textContent = READ_RETRY; btn.disabled = false; }
      if (typeof onFail === 'function') { try { onFail('audio unavailable'); } catch (e2) {} }
      return;
    }
    /* firstMax is set ONLY on the conversational path. The recital path calls the
       locked chunker exactly as it always has — byte-identical boundaries,
       byte-identical keys, the archive untouched. */
    var chunks = firstMax
      ? chunkConversational(plainText(text), max, firstMax)
      : chunkText(plainText(text), max);
    if (!chunks.length) {
      if (btn) { btn.textContent = READ_ALOUD; btn.disabled = false; }
      /* Nothing to say is a finished line, not a hung one. */
      if (typeof onDone === 'function') { try { onDone(); } catch (e) {} }
      return;
    }

    var useStyle = style || composeStyle(null);
    var useVoice = voice || VOICE_NAME_DEFAULT;

    var player = {
      cancelled: false,
      abort: (typeof AbortController !== 'undefined') ? new AbortController() : null,
      sources: [], nextStart: 0, ready: {}, toSchedule: 0,
      scheduled: 0, total: chunks.length, producerDone: false, started: false,
      btn: btn, watchdog: null, onDone: (typeof onDone === 'function' ? onDone : null),
      onFail: (typeof onFail === 'function' ? onFail : null)
    };
    voicePlayer = player;

    player.watchdog = setTimeout(function () {
      if (player.cancelled || player.started) return;
      console.error('Throttle: no audio after ' + START_TIMEOUT + 'ms — offering retry.');
      failStart(player);
    }, START_TIMEOUT);

    function finish() {
      if (player.cancelled) return;
      if (player.producerDone && player.scheduled === player.total && player.sources.length === 0) {
        clearWatchdog(player);
        if (player.btn) { player.btn.textContent = player.started ? READ_ALOUD : READ_RETRY; player.btn.disabled = false; }
        if (voicePlayer === player) voicePlayer = null;
        // Natural completion only (a Stop sets cancelled=true and returns above).
        if (player.started && player.onDone) { try { player.onDone(); } catch (e) {} }
        /* Every measure failed and nothing was ever heard: say so. */
        else if (!player.started && player.onFail) { try { player.onFail('every measure failed'); } catch (e) {} }
      }
    }
    function scheduleBuf(buf, rest, rate, idx) {
      if (player.cancelled) return;
      var useRate = rate || RATE_FAST;
      var src = ctx.createBufferSource();
      src.buffer = buf;
      try { src.playbackRate.value = useRate; } catch (e) {}
      src.connect(getVoiceBus());
      var at = Math.max(player.nextStart, ctx.currentTime + 0.05);
      src.start(at);
      var played = buf.duration / (useRate || 1);
      player.nextStart = at + played + (rest || 0);
      /* EACH MEASURE ANNOUNCED — added 4 Oct for sound.js. Its text, the
         moment it will sound and how long it lasts, read off the decoded
         buffer itself. A sound placed on a phrase can then land within a
         fraction of a second, instead of being estimated from reading pace
         across a whole paragraph. Additive and inert like voice-started: no
         symbol removed, no cache key touched, no chunk boundary moved. */
      try {
        var ch = (typeof idx === 'number' && chunks[idx]) ? chunks[idx] : null;
        window.dispatchEvent(new CustomEvent('amenti:measure', { detail: {
          index: idx, at: at, duration: played,
          text: ch ? (ch.text != null ? ch.text : String(ch)) : ''
        } }));
      } catch (e) {}
      player.scheduled++;
      player.sources.push(src);
      if (!player.started) {
        player.started = true;
        clearWatchdog(player);
        /* THE FIRST SOUND — added 26 Aug for amenti-dial.js.
           Nothing outside this file could know the moment audio actually
           begins: voicePlayer is set at line ~486, BEFORE the fetch, so
           isSpeaking() is already true throughout the wait. The dial needs
           this exact instant so the ring stops ON the first word instead of
           before it.
           Additive and inert: no symbol removed, no cache key touched, no
           chunk boundary moved. If nobody is listening, nothing happens. */
        try { window.dispatchEvent(new CustomEvent('amenti:voice-started')); } catch (e) {}
        if (player.btn) { player.btn.textContent = READ_STOP; player.btn.disabled = false; }
      }
      src.onended = function () {
        var k = player.sources.indexOf(src);
        if (k >= 0) player.sources.splice(k, 1);
        finish();
      };
    }
    function drain() {
      while (Object.prototype.hasOwnProperty.call(player.ready, player.toSchedule)) {
        var entry = player.ready[player.toSchedule];
        delete player.ready[player.toSchedule];
        player.toSchedule++;
        if (entry && entry.buf) scheduleBuf(entry.buf, entry.rest, entry.rate, player.toSchedule - 1);
        else { player.scheduled++; finish(); }
      }
    }

    var cap = CHUNK_LOOKAHEAD + 1, next = 0, inflight = 0;
    function done() {
      inflight--;
      if (player.cancelled) return;
      if (next >= chunks.length && inflight === 0) { player.producerDone = true; finish(); }
      else pump();
    }
    function pump() {
      while (!player.cancelled && inflight < cap && next < chunks.length) {
        (function (idx) {
          inflight++;
          fetchChunkBytes(chunks[idx], useStyle, useVoice, player.abort ? player.abort.signal : null)
            .then(function (bytes) {
              if (player.cancelled) return null;
              return decodeAudio(ctx, bytes);
            })
            .then(function (buf) {
              if (!player.cancelled) { player.ready[idx] = buf ? { buf: buf, rest: chunks[idx].rest, rate: chunks[idx].rate } : null; drain(); }
              done();
            }, function (err) {
              if (!player.cancelled) {
                console.error('Throttle chunk ' + idx + ' failed:', err && err.message);
                player.ready[idx] = null; drain();
              }
              done();
            });
        })(next);
        next++;
      }
    }
    pump();
  }

  /* speakReading() is retired — Amenti.throttle.speak is now a facade over speak(). */

  /* ---- attach: make any existing button a Read-aloud toggle ---------------- */
  // opts.text   : string OR function returning the text/markdown to read
  // opts.figure : display name (string OR function) for embodiment; optional
  // opts.label  : initial button label (default "🔊 Read aloud")
  function attach(btn, opts) {
    if (!btn) { console.warn('Throttle.attach: no button given'); return; }
    opts = opts || {};
    if (opts.label != null) btn.textContent = opts.label;
    else if (!btn.textContent) btn.textContent = READ_ALOUD;
    function val(x) { return (typeof x === 'function') ? x() : x; }
    btn.addEventListener('click', function () {
      var text = val(opts.text);
      var figure = val(opts.figure);
      speak(text || '', { btn: btn, figure: figure || '', register: 'recital' });
    });
    return btn;
  }

  /* ── THE ONE ENTRY POINT ─────────────────────────────────────────────────
     speak(text, opts)
       opts.figure    display name — resolves dialect/voice from the roster
       opts.register  'recital' (archive, cached, locked) | 'conversational'
       opts.move      warm|cool|sharp|grave|danger|humour — conversational ONLY
       opts.profile   'recital' | 'gabriel' | 'counsel' — the chunker
       opts.btn       optional button to drive (Read aloud / Stop / Retry)
       opts.onDone    natural end of speech
     ──────────────────────────────────────────────────────────────────────── */
  function speak(text, opts) {
    opts = opts || {};
    var conversational = (opts.register === 'conversational');
    var max = PROFILES[opts.profile] || (conversational ? PROFILES.counsel : CHUNK_MAX);
    var firstMax = conversational ? CONV_FIRST_MAX : 0;   // 0 on the recital path. Always.
    var btn = opts.btn || null;

    try {
      var active = voicePlayer;
      if (active) {
        var sameBtn = (active.btn === btn);
        stopReading();
        if (sameBtn && btn) return;          // a second tap on the same button = Stop
      }
      if (btn) { btn.textContent = '\u2026 generating'; btn.disabled = true; }

      resolveVoice(opts.figure).then(function (v) {
        if (btn && btn.disabled === false) return;
        var style = conversational
          ? composeConversational(v && v.figure, opts.move)     // varies freely — never cached
          : (v && v.style);                                     // LOCKED — the archive
        startReading(text, btn, style, (v && v.voice) || VOICE_NAME_DEFAULT, opts.onDone, max, firstMax, opts.onFail);
      }, function () {
        var style = conversational ? composeConversational(null, opts.move) : composeStyle(null);
        startReading(text, btn, style, VOICE_NAME_DEFAULT, opts.onDone, max, firstMax, opts.onFail);
      });
    } catch (e) {
      console.error('Voice start failed:', e && e.message);
      if (btn) { btn.textContent = READ_RETRY; btn.disabled = false; }
      if (typeof opts.onDone === 'function') { try { opts.onDone(); } catch (e2) {} }
    }
  }

  /* warm(text, figureName) — fetch a RECITAL text ahead of time, exactly as
     speak(text, { figure, register: 'recital' }) would, so it plays without a
     render wait. Same chunker, same style, same voice, same fallback when the
     figure is unknown — that sameness is the whole contract, because a warm
     that differed by one byte would fetch and pay for a clip nothing plays.
     Returns a Promise that resolves when every measure is on the shelf or has
     failed (it never rejects). */
  function warm(text, figureName) {
    return resolveVoice(figureName).then(function (v) {
      return { style: v && v.style, voice: (v && v.voice) || VOICE_NAME_DEFAULT };
    }, function () {
      return { style: composeStyle(null), voice: VOICE_NAME_DEFAULT };
    }).then(function (sv) {
      var style = sv.style || composeStyle(null);
      var chunks = chunkText(plainText(text), CHUNK_MAX);
      return Promise.all(chunks.map(function (c) {
        var k = shelfKey(c, style, sv.voice);
        if (!shelf[k]) shelfPut(k, fetchChunkBytesLive(c, style, sv.voice, null));
        return shelf[k] ? shelf[k].then(function () { return true; }, function () { return false; }) : false;
      }));
    });
  }

  Amenti.voice = {
    __v: 2,        /* 2 = the conversational fast opener. Recital boundaries UNCHANGED. */
    speak: speak,
    stop: stopReading,
    isSpeaking: function () { return !!voicePlayer; },
    attach: attach,
    chunk: function (t, profile) { return chunkText(plainText(t), PROFILES[profile] || CHUNK_MAX); },
    chunkConv: function (t) { return chunkConversational(plainText(t), PROFILES.counsel, CONV_FIRST_MAX); },
    plainText: plainText,
    resolveVoice: resolveVoice,
    REGISTERS: REG(),
    PROFILES: PROFILES,
    CONV_FIRST_MAX: CONV_FIRST_MAX,
    CHUNK_MAX: CHUNK_MAX
  };

  /* ── FACADES ─────────────────────────────────────────────────────────────
     Amenti.throttle has EIGHT call sites in Page1 alone, and library.js and
     Page2 have engines of their own that will be retired one at a time. Nothing
     is renamed until every caller has been grepped — that assumption is exactly
     what burned the last session. These are the old doors, opening onto the new
     room. Identical behaviour, byte-identical cache keys.
     ──────────────────────────────────────────────────────────────────────── */
  Amenti.throttle = {
    __v: 1,
    attach: attach,
    speak: function (text, btn, figureName, onDone, onFail) {
      return speak(text, { btn: btn, figure: figureName, onDone: onDone, onFail: onFail, register: 'recital' });
    },
    warm: warm,
    stop: stopReading,
    isReading: function () { return !!voicePlayer; },
    chunk: function (t) { return chunkText(plainText(t), CHUNK_MAX); },
    plainText: plainText,
    resolveVoice: resolveVoice,
    CHUNK_MAX: CHUNK_MAX,
    /* for a sound layer: the shared context, and the bus the voice runs on.
       Duck the bus, never the destination. */
    audioContext: function () { return getAudioCtx(); },
    voiceBus: function () { return getVoiceBus(); },
    rosterUrl: LOCAL_CSV           /* casting.js reads the same file */
  };

  /* The counsel's speaker. Was an inline half-copy in Page1 with no chunking and
     — critically — NO stop(), which is why the figure could not be interrupted.
     Now it is the real engine: chunked, streaming, and cancellable. */
  Amenti.conversation = {
    on: false,
    speak: function (text, figureName, onDone, meta) {
      if (!this.on) { if (typeof onDone === 'function') onDone(); return; }
      speak(text, {
        figure: figureName,
        register: 'conversational',
        move: meta && meta.register,          // the DECLARED move's register
        profile: 'counsel',
        onDone: onDone
      });
    },
    stop: stopReading,
    isSpeaking: function () { return !!voicePlayer; },
    styleFor: composeConversational
  };
})();
